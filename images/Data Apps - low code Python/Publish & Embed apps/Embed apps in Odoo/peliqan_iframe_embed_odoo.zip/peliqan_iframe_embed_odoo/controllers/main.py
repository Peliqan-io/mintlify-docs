from odoo import http
from odoo.http import request


class IframeEmbedController(http.Controller):
    @http.route("/iframe_embed/config", type="json", auth="user")
    def iframe_embed_config(self):
        """Return configuration and user context for the iframe widget."""
        params = request.env["ir.config_parameter"].sudo()
        base_url = params.get_param("iframe_embed.base_url", default="") or ""
        model_id = int(params.get_param("iframe_embed.model_id", default="0") or 0)
        model = request.env["ir.model"].sudo().browse(model_id) if model_id else False
        model_name = model.model if model and model.exists() else ""
        return {
            "base_url": base_url,
            "model": model_name,
            "user_id": request.env.user.id,
            "user_email": request.env.user.email or "",
        }
