from odoo import api, fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = "res.config.settings"

    iframe_embed_url = fields.Char(string="Iframe base URL")
    iframe_embed_model_id = fields.Many2one(
        "ir.model",
        string="Model to show iframe",
        domain=[("transient", "=", False)],
        help="Select the model whose form view should show the iframe",
    )

    @api.model
    def get_values(self):
        res = super().get_values()
        params = self.env["ir.config_parameter"].sudo()
        model_id = int(params.get_param("iframe_embed.model_id", default="0") or 0)
        res.update(
            iframe_embed_url=params.get_param("iframe_embed.base_url"),
            iframe_embed_model_id=self.env["ir.model"].browse(model_id)
            if model_id
            else False,
        )
        return res

    def set_values(self):
        super().set_values()
        params = self.env["ir.config_parameter"].sudo()
        params.set_param("iframe_embed.base_url", self.iframe_embed_url or "")
        params.set_param("iframe_embed.model_id", self.iframe_embed_model_id.id or False)
