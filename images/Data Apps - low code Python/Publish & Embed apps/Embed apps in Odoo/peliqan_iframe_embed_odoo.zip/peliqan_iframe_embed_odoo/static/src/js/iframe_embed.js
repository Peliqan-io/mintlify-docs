/** @odoo-module */

import { onMounted, onWillStart, useEffect, onPatched } from "@odoo/owl";
import { FormRenderer } from "@web/views/form/form_renderer";
import { patch } from "@web/core/utils/patch";
import { useService } from "@web/core/utils/hooks";
import { rpc } from "@web/core/network/rpc";

console.log("IframeEmbed: Module loaded");

const CONTAINER_CLASS = "oe-iframe-embed";
const FRAME_CLASS = "oe-iframe-embed__frame";

patch(FormRenderer.prototype, {
    setup() {
        super.setup();
        console.log("IframeEmbed: setup called");
        this.notification = useService("notification");
        this.iframeConfig = null;

        onWillStart(async () => {
            try {
                this.iframeConfig = await rpc("/iframe_embed/config", {});
            } catch (error) {
                this.iframeConfig = null;
                this.notification.add(
                    this.env._t("Could not load iframe configuration."),
                    { type: "warning" }
                );
            }
        });

        useEffect(
            () => {
                this._renderIframe();
            },
            () => [this.props.record?.resId, this.props.record?.resModel, this.iframeConfig]
        );

        onMounted(() => this._renderIframe());
        onPatched(() => this._renderIframe());
    },

    _renderIframe() {
        let targetEl = document.querySelector(".o_form_sheet_bg") || document.querySelector(".o_form_view");

        console.log("IframeEmbed: _renderIframe called", { el: targetEl });

        if (!targetEl) {
            console.log("IframeEmbed: No target element found");
            return;
        }

        const existing = targetEl.querySelector(`.${CONTAINER_CLASS}`);
        if (existing) {
            existing.remove();
        }

        console.log("IframeEmbed: Config", this.iframeConfig);
        console.log("IframeEmbed: Record", this.props.record);

        if (
            !this.iframeConfig ||
            !this.iframeConfig.base_url ||
            !this.props.record?.resId ||
            this.props.record.resModel !== this.iframeConfig.model
        ) {
            console.log("IframeEmbed: Validation failed", {
                config: !!this.iframeConfig,
                baseUrl: this.iframeConfig?.base_url,
                resId: this.props.record?.resId,
                modelMatch: this.props.record?.resModel === this.iframeConfig?.model,
                recordModel: this.props.record?.resModel,
                configModel: this.iframeConfig?.model
            });
            return;
        }

        const iframeUrl = this._buildUrl(
            this.iframeConfig.base_url,
            this.props.record.resId,
            this.props.record.resModel
        );

        const container = document.createElement("div");
        container.classList.add(CONTAINER_CLASS);

        const iframe = document.createElement("iframe");
        iframe.classList.add(FRAME_CLASS);
        iframe.src = iframeUrl;
        iframe.setAttribute("frameborder", "0");
        iframe.setAttribute("allowfullscreen", "true");
        iframe.style.width = "100%";
        iframe.style.minHeight = "400px";

        container.appendChild(iframe);

        const insertionTarget = targetEl.querySelector(".o_form_sheet") || targetEl;
        insertionTarget.appendChild(container);
    },

    _buildUrl(baseUrl, resId, model) {
        const params = {
            user_id: this.iframeConfig.user_id,
            user_email: this.iframeConfig.user_email || "",
            object_id: resId,
            object_model: model,
        };

        try {
            const url = new URL(baseUrl, window.location.origin);
            Object.entries(params).forEach(([key, value]) =>
                url.searchParams.set(key, value)
            );
            return url.toString();
        } catch {
            const search = new URLSearchParams(params).toString();
            const separator = baseUrl.includes("?") ? "&" : "?";
            return `${baseUrl}${separator}${search}`;
        }
    },
});
