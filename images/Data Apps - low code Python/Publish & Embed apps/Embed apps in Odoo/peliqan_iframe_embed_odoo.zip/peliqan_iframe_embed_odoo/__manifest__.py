{
    "name": "Iframe Embed",
    "version": "18.0.1.0.0",
    "summary": "Show a configurable iframe on selected record detail pages",
    "category": "Tools",
    "depends": ["base", "web"],
    "data": [
        "views/res_config_settings_views.xml",
    ],
    "assets": {
        "web.assets_backend": [
            "iframe_embed/static/src/js/iframe_embed.js",
        ],
    },
    "license": "LGPL-3",
    "installable": True,
    "application": False,
}
